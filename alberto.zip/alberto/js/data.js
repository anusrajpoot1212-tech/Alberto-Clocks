// Product data store (JSON). Also available as data/products.json
var PRODUCTS = [

  // =========================
  // VINTAGE - 8 PRODUCTS
  // =========================

  {
    "id": 1,
    "name": "Heritage Pocket 1920",
    "brand": "Bulova",
    "cat": "Vintage",
    "price": 1250,
    "img": "images/vp.jpg",
    "desc": "Hand-wound pocket watch with Roman numerals and brass case.",
    "specs": ["Manual wind", "Brass case 48mm", "Enamel dial"]
  },

  {
    "id": 2,
    "name": "Classic Automatic 58",
    "brand": "Seiko",
    "cat": "Vintage",
    "price": 890,
    "img": "images/vp1.jpg",
    "desc": "Mid-century dress watch on genuine leather strap.",
    "specs": ["Automatic", "36mm", "Leather strap"]
  },

  {
    "id": 3,
    "name": "Railroad Chronometer",
    "brand": "Bulova",
    "cat": "Vintage",
    "price": 1640,
    "img": "images/vp2.jpg",
    "desc": "Restored railroad-grade timepiece with classic vintage styling.",
    "specs": ["21 jewels", "Gold-filled", "Restored 2025"]
  },

  {
    "id": 11,
    "name": "Omega Seamaster Classic",
    "brand": "Omega",
    "cat": "Vintage",
    "price": 2850,
    "img": "images/vp3.jpg",
    "desc": "Elegant 1960s-inspired automatic watch with a timeless silver dial.",
    "specs": ["Automatic", "34mm", "Leather strap"]
  },

  {
    "id": 12,
    "name": "Longines Heritage",
    "brand": "Longines",
    "cat": "Vintage",
    "price": 3150,
    "img": "images/vp4.jpg",
    "desc": "Classic vintage dress watch featuring a refined cream dial.",
    "specs": ["Manual wind", "35mm", "Gold-tone case"]
  },

  {
    "id": 13,
    "name": "Tudor Oyster Classic",
    "brand": "Tudor",
    "cat": "Vintage",
    "price": 4200,
    "img": "images/vp5.jpg",
    "desc": "Traditional Oyster-style vintage watch with understated elegance.",
    "specs": ["Automatic", "36mm", "Stainless steel"]
  },

  {
    "id": 14,
    "name": "Citizen Cosmotron",
    "brand": "Citizen",
    "cat": "Vintage",
    "price": 1180,
    "img": "images/vp6.jpg",
    "desc": "Distinctive 1970s-inspired electronic watch with a blue dial.",
    "specs": ["Electronic", "37mm", "Blue sunburst dial"]
  },

  {
    "id": 15,
    "name": "Classic Dress 1965",
    "brand": "Hamilton",
    "cat": "Vintage",
    "price": 1950,
    "img": "images/vp7.jpg",
    "desc": "Elegant mid-century dress watch with a clean minimalist dial.",
    "specs": ["Manual wind", "35mm", "Leather strap"]
  },


  // =========================
  // LUXURY - 8 PRODUCTS
  // =========================

  {
    "id": 4,
    "name": "Oyster Datejust Gold",
    "brand": "Rolex",
    "cat": "Luxury",
    "price": 38500,
    "img": "images/lp1.jpg",
    "desc": "18k yellow gold with fluted bezel and President bracelet.",
    "specs": ["Calibre 3235", "36mm 18k gold", "100m water resistant"]
  },

  {
    "id": 5,
    "name": "Two-Tone Chronograph",
    "brand": "Michael Kors",
    "cat": "Luxury",
    "price": 450,
    "img": "images/lp2.jpg",
    "desc": "Bold two-tone chronograph with tachymeter bezel.",
    "specs": ["Quartz chrono", "44mm", "Stainless & gold"]
  },

  {
    "id": 6,
    "name": "Eco-Drive Signature",
    "brand": "Citizen",
    "cat": "Luxury",
    "price": 1290,
    "img": "images/lp3.jpg",
    "desc": "Light-powered elegance that never needs a battery.",
    "specs": ["Eco-Drive", "Sapphire crystal", "Perpetual calendar"]
  },

  {
    "id": 7,
    "name": "Precisionist Grand",
    "brand": "Bulova",
    "cat": "Luxury",
    "price": 795,
    "img": "images/lp4.jpg",
    "desc": "262 kHz high-frequency quartz with continuous sweep.",
    "specs": ["Precisionist", "46mm", "300m water resistant"]
  },

  {
    "id": 16,
    "name": "Royal Chronograph",
    "brand": "Tag Heuer",
    "cat": "Luxury",
    "price": 5200,
    "img": "images/lp5.jpg",
    "desc": "Sporty luxury chronograph combining precision with premium styling.",
    "specs": ["Automatic chrono", "42mm", "Sapphire crystal"]
  },

  {
    "id": 17,
    "name": "Classic Gold Master",
    "brand": "Tissot",
    "cat": "Luxury",
    "price": 1850,
    "img": "images/lp6.jpg",
    "desc": "Sophisticated gold-tone timepiece designed for formal occasions.",
    "specs": ["Automatic", "40mm", "Sapphire crystal"]
  },

  {
    "id": 18,
    "name": "Premier Automatic",
    "brand": "Seiko",
    "cat": "Luxury",
    "price": 1450,
    "img": "images/lp7.jpg",
    "desc": "Premium automatic watch with a refined modern case design.",
    "specs": ["Automatic", "41mm", "Stainless steel"]
  },

  {
    "id": 19,
    "name": "Executive Moonphase",
    "brand": "Frederique Constant",
    "cat": "Luxury",
    "price": 4950,
    "img": "images/lp8.jpg",
    "desc": "Elegant luxury watch featuring a sophisticated moonphase display.",
    "specs": ["Automatic", "40mm", "Moonphase"]
  },


  // =========================
  // SMART - 8 PRODUCTS
  // =========================

  {
    "id": 8,
    "name": "Pulse Active 3",
    "brand": "Alberto Tech",
    "cat": "Smart",
    "price": 299,
    "img": "images/sp1.jpg",
    "desc": "Fitness smartwatch with AMOLED display and GPS.",
    "specs": ["Heart-rate & SpO2", "GPS", "7-day battery"]
  },

  {
    "id": 9,
    "name": "Gen 6 Hybrid",
    "brand": "Michael Kors",
    "cat": "Smart",
    "price": 355,
    "img": "images/sp2.jpg",
    "desc": "Fashion meets function with smart connectivity.",
    "specs": ["Smart OS", "NFC payments", "Fast charge"]
  },

  {
    "id": 10,
    "name": "CZ Smart Touch",
    "brand": "Citizen",
    "cat": "Smart",
    "price": 425,
    "img": "images/sp3.jpg",
    "desc": "Smart features with Citizen's classic styling.",
    "specs": ["Touchscreen", "Sleep tracking", "Swim proof"]
  },

  {
    "id": 20,
    "name": "Galaxy Active Pro",
    "brand": "Samsung",
    "cat": "Smart",
    "price": 399,
    "img": "images/sp4.jpg",
    "desc": "Modern smartwatch with health tracking and a bright AMOLED display.",
    "specs": ["AMOLED", "GPS", "Health tracking"]
  },

  {
    "id": 21,
    "name": "Watch Series Pro",
    "brand": "Apple",
    "cat": "Smart",
    "price": 699,
    "img": "images/sp5.jpg",
    "desc": "Premium smartwatch with advanced fitness and connectivity features.",
    "specs": ["OLED display", "GPS", "Fitness tracking"]
  },

  {
    "id": 22,
    "name": "Venu Sport",
    "brand": "Garmin",
    "cat": "Smart",
    "price": 449,
    "img": "images/sp6.jpg",
    "desc": "Fitness-focused smartwatch built for everyday activity tracking.",
    "specs": ["GPS", "Heart-rate monitor", "Long battery"]
  },

  {
    "id": 23,
    "name": "GT Performance",
    "brand": "Huawei",
    "cat": "Smart",
    "price": 329,
    "img": "images/s7.jpg",
    "desc": "Stylish smartwatch with sports modes and health monitoring.",
    "specs": ["AMOLED", "100+ workout modes", "Long battery"]
  },

  {
    "id": 24,
    "name": "Fit Pro Max",
    "brand": "Amazfit",
    "cat": "Smart",
    "price": 249,
    "img": "images/s8.jpg",
    "desc": "Lightweight fitness smartwatch with GPS and activity tracking.",
    "specs": ["AMOLED", "GPS", "Activity tracking"]
  }

];